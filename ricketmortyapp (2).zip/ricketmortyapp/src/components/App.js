import '../styles/App.css';
import React, { useState, useEffect } from "react";
import Header from './Header';
import Footer from './Footer';
import CardList from "./Cardlist";
let api = `https://rickandmortyapi.com/api/character`;

// function RickApi() {
//   const getUsers = () => {
//     return fetch("https://rickandmortyapi.com/api/character", {
//       type: "GET",
//     }).then((res) => res.json());

//   };

//   return {
//     getUsers,
//   };
// }

function App() {
  return (
    
    <div className="App">
      <div>
        <Header></Header>
        <div className='row'>
          <div className='col-2'></div>
          <div className='col-8 text-center'><CardList></CardList></div>
          <div className='col-2'></div>
          
        </div>
        
      </div>
    </div>
  );
  
 
 
}




export default App;
