import '../styles/App.css';
import React, { useState, useEffect } from "react";
import Header from './Header';

    function Details() {
        return (
        <div className="Details">
            <Header></Header>
            
        </div>
        );
    }