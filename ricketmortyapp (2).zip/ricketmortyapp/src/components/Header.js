import React from 'react';
import logo from '../assets/logo-rick-et-morty.svg';
import { FontAwesomeIcon } from '../node_modules/@fortawesome/react-fontawesome';
import { faHtml5, faCss3Alt, faJs, faReact } from '../node_modules/@fortawesome/free-brands-svg-icons';

function Header() {
  return (
    <div>
        <header className="App-header">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous"/>
        </header>
        <div className="App">
            <img src={logo} className="mx-auto d-block mb-3"></img>
            <div className="text-light text-center">
                Rick et Morty : apprentissage de react sans prise de tete
            </div>
            <div className='text-center'>
            <FontAwesomeIcon icon={faHtml5} style={{ color: "#ffae00", fontSize: "4rem" }} />
            <FontAwesomeIcon icon={faCss3Alt} style={{ color: "#3700ff", fontSize: "4rem" }} />
            <FontAwesomeIcon icon={faJs} style={{ color: "#f1f500", fontSize: "4rem" }} />
            <FontAwesomeIcon icon={faReact} style={{ color: "#5cf4ff", fontSize: "4rem" }} />

        </div>
        </div>
    </div>
  )
}
export default Header